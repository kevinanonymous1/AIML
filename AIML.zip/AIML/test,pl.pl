cat(tom).
likes(ruby,noodles).
likes(niby,burger).
friends(pooja,geeta).
friends(geeta,pooja).
friendship(X,Y):-friends(X,Y);friends(Y,X).
area(R,A):- Pi is 3.14,A is(Pi*R*R),
    write("area of circle is"),write(A).
